const withLess = require('@zeit/next-less')
const withCss = require('@zeit/next-css')
const withPlugins = require('next-compose-plugins')
// node_modules中需要编译的组件配置
const withTM = require('next-transpile-modules')(['nebula-ui','antd'])
const withFont = require('next-fonts')
// const withOptImage = require('next-optimized-images');

module.exports = withPlugins([[withTM],[withFont],[withLess,{lessLoaderOptions: {javascriptEnabled: true}}],[withCss]],{
    // exportPathMap: async function (defaultPathMap) {
    //     return {
    //         '/': { page: '/' },
    //         '/user': { page: '/' }
    //     }
    // },
    distDir: 'build',
    webpack(config){
        // config.resolve = Object.assign({},config.resolve,{
        //     extensions:['.js','.json','.jsx','.ts','.tsx','.png','.gif','.jpg','.svg','.woff','.eot','.ttf']
        // })
        config.module.rules.push({
            test: /\.(gif|jpg|png|svg)\??.*$/,
            use: [
                {
                    loader: 'url-loader',
                    options: {
                        name: "[name].[hash:8].[ext]",
                        publicPath: `/_next/static/image/`,
                        outputPath: "static/image/",
                        limit: 500000
                    }
                }
            ]
        })
        config.module.rules.push({
            test: /\.(woff|woff2|eot|ttf|otf)$/,
            use:[
                {
                    loader: 'url-loader',
                    options: {
                        limit: 500000,
                        publicPath: `/_next/static/fonts/`,
                        outputPath: `static/fonts/`,
                        name: '[name]-[hash].[ext]'
                    }
                }
            ]
        })
        return config;
    }
})