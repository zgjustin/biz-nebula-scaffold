
const express = require('express')
var http = require("http")
const { parse } = require('url')
var bodyParser = require("body-parser");  
const {createProxyMiddleware} = require('http-proxy-middleware')
const next = require('next')
const dev = process.env.NODE_ENV !== 'production'
const RouteSetting = require('./route.json')
const app = next({ dev })
const handle = app.getRequestHandler()
const fs = require("fs")
const path = require('path');
const less = require('less');
const iconv = require('iconv-lite');

const port = 5700; //parseInt(process.env.PORT, 10) || 3000;

const getPathArray = function (routePath,menu){
  if(!menu) menu=RouteSetting;
  menu.forEach(v=>{
      let {children,...baseData} = v;
      routePath.push(baseData);
      if(children){
          getPathArray(routePath,children);
      }
  })
}
//API 主机头配置
const domain = {host:'139.9.236.174',port:'5900',path:'/v1'}
//http API接口请求
const request = (url,method,data,callback,header)=>{
  if(typeof data==='object'){
    data = JSON.stringify(data);
    //node默认为unicode编码 需要转换为utf8传http数据
    data = iconv.encode(data,'utf8');
  }
  let opt = {
    host:'localhost',
    port:port,
    method:method,
    path:`${domain.path}${url}`,
    protocol:'http:',
    headers:{
        "Content-Type": 'application/x-www-form-urlencoded; charset=utf-8',
        "Content-Length": data.length
    }
  }
  if(header){
    opt.headers = {...opt.headers,...header}
  }
  let body = ''
  let req = http.request(opt, function(res) {
      res.on('data',function(result){
        body += result;
      }).on('end', function(){
        let result=body?JSON.parse(body):{success:false,errorMsg:'请求数据错误!'}
        callback && callback(result,res);
      });
  }).on('error', function(e) {
      console.log("error: " + e.message);
  })
  req.write(data+'\n');
  req.end();
}

/**
 * 编译less文件到对应的文件
 * @param {*} input less文本
 * @param {*} fileName 输入文件名
 */
async function complieLess(input,fileName){
  return await new Promise(resolve=>{
      less.render(input,{javascriptEnabled:true},(error,out)=>{
          if(error){
              console.error('less render:',error);
              resolve(false);
              return;
          }
          fs.writeFile(fileName,out.css,function(err) {
            if (err) {
              resolve(false);
            }
            resolve(true);
          });
      })
  })
}

app.prepare().then(() => {
  const server = express();
  server.use(createProxyMiddleware('/v1', {
    target: 'http://139.9.236.174:5900',
    // target: 'http://192.168.10.120:6500',
    secure: false,
    pathRewrite: {'^/v1' : '/v1'},
    changeOrigin: true
  }))
  server.use(bodyParser.json({limit: '2mb'})); 
  server.use(bodyParser.urlencoded({ extended: false })); 
  //保存并生成主题样式文件
  server.post('/nebula/saveTheme',(req,res)=>{
    let reqCookie = req.headers['cookie'];
    let accept = req.headers['accept'];
    let encode = req.headers['accept-encoding'];
    let language = req.headers['accept-language']
    let contentType = req.headers['content-type']
    const header = {
      cookie:reqCookie,
      Accept:accept,
      'Accept-Encoding':encode,
      'Accept-Language':language,
      'Content-Type': contentType.toLowerCase()
    }
    let postData = req.body;
    request('/nebula/theme','POST',postData,(data)=>{
      if(data.success){
        //保存主题布局文件 将配置信息写入系统配置文件中，依赖此文件进行全局输入读取
        const sysFilePath = path.join(process.cwd(), './static/theme/system.json');
        const {color,customTheme,theme,...sysConfig} = postData;
        sysConfig.lastTime = new Date().getTime();
        fs.writeFile(sysFilePath,JSON.stringify(sysConfig),function(err) {
            if (err) {
              data.success=false;
              data.errorMsg='保存配置文件失败';
              res.json(data);
            }
        });
        //生成样式文件
        const themeVar = color && color.variables;
        if(themeVar){
          let themeVarString = Object.entries(themeVar).map(([k,v])=>`${k}:${v}`).join(';');
          themeVarString= `@import './static/theme/less/default.less';${themeVarString};@import './static/theme/less/index.less';`;
          complieLess(themeVarString,path.join(process.cwd(), './static/css/nebula.css')).then(result=>{
            if(!result){
              data.success=false;
              data.errorMsg='保存主题失败';
              res.json(data);
            }
            res.json(data);
          })
        }
        return;
      }
      res.json(data);
    },header);
  })
  server.get('*',(req,res)=>{
    // Be sure to pass `true` as the second argument to `url.parse`.
    // This tells it to parse the query portion of the URL.
    const parsedUrl = parse(req.url, true)
    const { pathname, query } = parsedUrl
    let menuPath = [];
    getPathArray(menuPath);
    const currPath = menuPath.find(v=>v.path===pathname);
    if (currPath) {
      //验证鉴权 
      let apiCookies = req.headers['cookie'];
      if(!apiCookies){
        //跳转登录页
        res.redirect('/login');
        return;
      }
      request('/nebula/users/findByPrincipal','GET',{},(data)=>{
        if(data.success){
          const userInfo = data.data;
          if(userInfo){
            delete userInfo.password;
          }
          res.userinfo = userInfo;
          res.layoutinfo = {
            system_title:"nebula业务构建平台演示",
            table:1,
            card:false,
            frame:"classical"
          }  
          //读取系统布局信息
          fs.readFile(path.join(process.cwd(), './static/theme/system.json'),function(err,data) {
            if (!err && data) {
              res.layoutinfo = JSON.parse(data.toString());
            }
            app.render(req, res, '/', query);
            return;
          });
          app.render(req, res, '/', query)
          return;
        }
        //跳转登录页
        res.redirect('/login');
      },{cookie:apiCookies})
    } else {
      handle(req, res, parsedUrl)
    }
  })
  server.listen(port, err => {
    if (err) throw err
    console.log(`> Ready on http://localhost:${port}`)
  })
})