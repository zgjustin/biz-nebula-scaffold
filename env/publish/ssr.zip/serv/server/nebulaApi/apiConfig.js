"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    /**
     * 用户鉴权 查询用户是否登录
     */
    UserFindByPrincipal: '/nebula/users/findByPrincipal',
    /**
     * 通过Code创建实例
     */
    CreateInstanceFindByCode: '/kuiper/instances',
    /**
     * 保存主题
     */
    SaveTheme: '/nebula/theme',
    /**
     * 导入保存
     */
    SaveThemeImport: '/nebula/theme/import',
    /**
     * 查找主题
     */
    FindTheme: '/theme/findTheme',
    /**
     * 指定Id查找实例活动
     */
    activitiesFindById: '/kuiper/activities/findDetailsById',
    /**
     * 指定taskCode查找实例活动
     */
    activitiesFindByTaskCode: '/kuiper/activities/checkCreate',
    /**
     * 指定id查找模版信息
     */
    templateFindDetailsById: '/kuiper/templates/findDetailsById',
    /**
     * 指定服务名和实例id获取静态模型
     */
    staticInstanceById: '/nebula/servicableMethods/servicableMethodInvoke',
    /**
     * 指定实例id获取动态模型
     */
    dynamicInstanceById: '/kuiper/dynamicInstatnces/findDetailsByFormInstanceId',
    /**
     * 指定模版id获取布局
     */
    templateLayoutByTemplateId: '/kuiper/templateLayouts/findDetailsByTemplateId',
    /**
     * 指定模版Id获取事件
     */
    templateEventByTemplateId: '/kuiper/templateEvents/findByTemplateId',
    /**
     * 指定模版Id和布局类型获取可见性
     */
    templateVisibilityByTemplateId: '/kuiper/templatevisibilities/findDetailsByTemplateIdAndLayoutType',
    /**
     * 指定列表code获取列表配置信息
     */
    listTemplateFindByCode: '/kuiper/listTemplates/findDefaultContentByCode',
    /**
     * 指定列表id获取列表基本信息
     */
    listTemplateFindById: '/kuiper/listTemplates/findDetailsById',
    /**
     * 指定列表id获取列表配置信息
     */
    listTemplateContentFindById: '/kuiper/listTemplates/findConentById',
    /**
     * 获得当前登录人的所有按钮权限
     */
    buttonsFindByCurrentUser: '/nebula/buttons/findByCurrentUser',
    /**
     * 获得当前登录人的所有菜单
     */
    CompetencesViewItemFindByCurrentUser: '/nebula/competences/findByCurrentUser?viewItem=true'
};
