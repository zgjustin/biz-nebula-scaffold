"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const httpRequest_1 = __importDefault(require("../httpRequest"));
const apiConfig_1 = __importDefault(require("./apiConfig"));
const apiConfig_2 = __importDefault(require("./apiConfig"));
const modelTransform_1 = __importDefault(require("../utils/modelTransform"));
/**
 * NebulaApi 接口调用处理
 * 业务默认处理
 */
class NebulaApi {
    constructor() {
        this.nebulaRequest = new httpRequest_1.default();
        this.defaultErrorMsg = '请求错误';
    }
    /**
     * 请求准备
     * @param header 请求头信息，拦截拿取到的header头
     * @param host 主机头 非必填
     * @param port 端口号 非必填
     */
    ready(header, host, port, path) {
        let reqCookie = header['cookie'];
        let accept = header['accept'];
        let encode = header['accept-encoding'];
        let language = header['accept-language'];
        let contentType = header['content-type'];
        let defaultHeader = {};
        defaultHeader['cookie'] = reqCookie || '';
        if (accept)
            defaultHeader['Accept'] = accept;
        if (encode)
            defaultHeader['Accept-Encoding'] = encode;
        if (language)
            defaultHeader['Accept-Language'] = language;
        if (contentType)
            defaultHeader['Content-Type'] = contentType.toLowerCase();
        this.nebulaRequest.configDefault({
            host: host || 'localhost',
            port: port || 5700,
            rootPath: '/v1',
            headers: defaultHeader
        });
    }
    /**
     * 获取请求的错误信息
     */
    getError() {
        return this.requstError;
    }
    setError(code, msg, apiResult) {
        this.requstError = {
            errorMsg: msg || this.defaultErrorMsg,
            responseCode: code,
            success: false,
            apiResult
        };
        console.error('nebula-request:', this.requstError.errorMsg);
    }
    /**
     * 发起请求API
     * @param url
     * @param method
     * @param data
     * @param callback
     */
    request(url, method, data) {
        return this.nebulaRequest.send(url, method, data).then((result) => {
            if (result && result.success) {
                this.requstError = null;
                // console.log('backJson:'+url,result)
                return result.data || {};
            }
            this.setError(result.responseCode, result.errorMsg, result);
            return false;
        }).catch(error => {
            this.setError(error.code, error.message);
            return false;
        });
    }
    /**
     * Get请求
     * @param url
     * @param data
     * @param callback
     */
    get(url, data) {
        return this.request(url, 'GET', data);
    }
    /**
     * Post请求
     * @param url
     * @param data
     * @param callback
     */
    post(url, data) {
        return this.request(url, 'POST', data);
    }
    /**
     * 获取鉴权信息
     * 返回鉴权信息
     */
    async getAuthenticate() {
        let data = await this.get(apiConfig_1.default.UserFindByPrincipal, {});
        if (!data)
            return data;
        //移除返回数据中的密码字段
        let { password, ...otherInfo } = data;
        return otherInfo;
    }
    /**
     * 根据指定的code和version获得活动数据 需要注入cookie
     * @param {*} code
     * @param {*} version
     */
    async getActivityByTemplate(code, version) {
        let buildUrl = `${apiConfig_1.default.CreateInstanceFindByCode}/${code}`;
        if (version)
            buildUrl += `/${version}`;
        this.nebulaRequest.header({ 'Content-Type': 'application/json; charset=utf-8' });
        return await this.post(buildUrl, {});
    }
    /**
     * 指定taskCode，instanceId，visibilityName查询实例信息
     * @param taskCode
     * @param instanceId
     * @param visibility
     */
    async getActivityByTaskCode(taskCode, instanceId, visibilityName) {
        if (!taskCode) {
            this.setError('01', '参数taskCode必须指定!');
            return false;
        }
        let postParams = { taskCode };
        if (instanceId)
            postParams.instanceId = instanceId;
        if (visibilityName)
            postParams.visibilityName = visibilityName;
        this.nebulaRequest.header({ 'Content-Type': 'application/json; charset=utf-8' });
        return await this.post(apiConfig_2.default.activitiesFindByTaskCode, postParams);
    }
    /**
     * 根据活动id和模版布局类型获取对应的实例数据 需要注入cookie
     * @param {*} activityId 活动id
     * @param {*} layoutType 布局类型 默认布局pc端 1
     */
    async getTemplateInstance(activityId, layoutType = 1) {
        let activity = await this.get(apiConfig_1.default.activitiesFindById, { id: activityId });
        if (!activity)
            return activity;
        // 实例信息
        let instances = activity.instance;
        // 模版的基本信息
        let template = activity.template;
        // 模版创建人信息
        let creator = activity.creator;
        // 模版当前的可见性信息
        let templateVisibility = activity.templateVisibility;
        // 模版当前的活动id
        let activities = {
            id: activity.id
        };
        //用promise批量查询数据，提升网络性能
        // 使用模版id 获取模版的基本信息
        let templatePromise = this.get(apiConfig_2.default.templateFindDetailsById, { id: template.id });
        //获取表单模版信息
        let formDataRequest;
        let entity;
        if (template.type === 'static' && template.persistentClassName) {
            // 当前模型是静态模型 通过静态模型接口获取数据
            let arr = template.persistentClassName.split('.');
            entity = arr && arr.length > 0 && arr[arr.length - 1];
            this.nebulaRequest.header({ 'Content-Type': 'application/json; charset=utf-8' });
            formDataRequest = this.post(`${apiConfig_2.default.staticInstanceById}?serviceName=${entity}Service.findDetailsByFormInstanceId`, {
                invokeParams: { formInstanceId: instances.id }
            });
        }
        else if (template.type === 'dynamic') {
            // 当前模型是动态模型 通过动态模型接口获取数据
            formDataRequest = this.get(apiConfig_2.default.dynamicInstanceById, { formInstanceId: instances.id });
        }
        else {
            return false;
        }
        //获取模版布局
        let designRequest = this.get(apiConfig_2.default.templateLayoutByTemplateId, { templateId: template.id, layoutType: layoutType });
        //获取事件数据  
        let eventRequest = this.get(apiConfig_2.default.templateEventByTemplateId, { templateId: template.id });
        //获取指定布局类型的可见性  
        let visibilityRequst = this.get(apiConfig_2.default.templateVisibilityByTemplateId, { templateId: template.id, layoutType: layoutType });
        //批量查询数据
        let [design, event, visibility, formData, templateDetail] = await Promise.all([designRequest, eventRequest, visibilityRequst, formDataRequest, templatePromise]);
        if (!design)
            return false;
        if (!templateDetail)
            return false;
        //初始化模型数据
        let { properties, relations, groupRelations, itemRelations, } = templateDetail;
        // 得到当前的模版数据
        let model = {
            properties,
            relations,
            groupRelations,
            itemRelations,
        };
        // 进行模型数据解析
        let modelInfo = new modelTransform_1.default();
        modelInfo.init({ properties, relations, groupRelations, itemRelations });
        // 得到解析之后的模型数据 { name: propsObj }
        let fielddata = modelInfo.getFieldData();
        if (!fielddata) {
            return false;
        }
        const getPrimaryKey = () => {
            let index = properties && properties.findIndex((item) => item.primaryKey == true);
            let propertyName;
            if (index > -1) {
                propertyName = properties[index].propertyName;
            }
            return propertyName;
        };
        let fieldPrimaryKey;
        if (properties) {
            fieldPrimaryKey = getPrimaryKey();
        }
        //配置文件
        let config = {
            updateService: `${entity}Service.update`,
            createService: `${entity}Service.create`,
            saveFormService: `${entity}Service.createForm`,
            updateFormService: `${entity}Service.updateForm`,
            instances,
            template,
            activities,
            event,
            visibility: visibility,
            design,
            creator,
            templateVisibility,
            fieldPrimaryKey,
            fielddata,
            ruleName: templateVisibility
                ? templateVisibility.visibilityName
                : '',
            data: formData,
            model,
            activity
        };
        return config;
    }
    /**
     * 根据列表code获取对应的列表配置内容
     * @param code
     */
    async getListContentByCode(code) {
        let listData = await this.get(apiConfig_1.default.listTemplateFindByCode, { code });
        return listData;
    }
    /**
     * 根据列表id获取对应的列表配置内容
     * @param id
     */
    async getListContentById(id) {
        let reqPromises = [];
        reqPromises.push(this.get(apiConfig_1.default.listTemplateFindById, { id }));
        reqPromises.push(this.get(apiConfig_1.default.listTemplateContentFindById, { id }));
        let [details, setting] = await Promise.all(reqPromises);
        if (!details || !setting)
            return false;
        return {
            details,
            content: setting.content
        };
    }
    /**
     * 获取当前登录人的所有按钮权限
     */
    async getButtonAuthsByCurrentUser() {
        return await this.get(apiConfig_2.default.buttonsFindByCurrentUser, {});
    }
    /**
     * 获取当前登录人的所有菜单权限
     */
    async getCompetencesViewItemByCurrentUser() {
        return await this.get(apiConfig_2.default.CompetencesViewItemFindByCurrentUser, {});
    }
    /**
     * 获得登录人的按钮权限和菜单
     */
    async getUserButtonAuthAndMenu() {
        let [userAuths, userMenus] = await Promise.all([this.getButtonAuthsByCurrentUser(), this.getCompetencesViewItemByCurrentUser()]);
        return { userAuths, userMenus };
    }
}
exports.default = NebulaApi;
