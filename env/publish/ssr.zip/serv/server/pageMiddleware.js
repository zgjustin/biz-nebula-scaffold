"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const nebulaApi_1 = __importDefault(require("./nebulaApi"));
const file_1 = __importDefault(require("./file"));
const route_1 = __importDefault(require("../config/route"));
const url_1 = require("url");
const apiConfig_1 = __importDefault(require("./nebulaApi/apiConfig"));
const less_1 = __importDefault(require("less"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const _nebulaApi = new nebulaApi_1.default();
/**
 * 编译less文件到对应的文件
 * @param {*} input less文本
 * @param {*} fileName 输入文件名
 */
function complieLess(input, fileName) {
    return new Promise(resolve => {
        less_1.default.render(input, { javascriptEnabled: true }, (error, out) => {
            if (error) {
                console.error('less render:', error);
                resolve(false);
                return;
            }
            file_1.default.write(fileName, out.css).then(data => {
                resolve(data);
            });
        });
    });
}
/**
 * 处理page服务端逻辑
 */
class PageMiddleware {
    /**
     * 初始化中间件
     * /nebula/saveTheme
     */
    async init(app, req, res, appConfig) {
        this.systemAppConfig = appConfig;
        const handle = app.getRequestHandler();
        const parsedUrl = url_1.parse(req.url, true);
        const { pathname, query } = parsedUrl;
        //准备请求
        let readyHeader = {
            cookie: req.headers['cookie'],
            'content-type': 'application/x-www-form-urlencoded; charset=utf-8'
        };
        let { proxyRootPath, port } = appConfig || {};
        res.appConfig = appConfig;
        //获取扩展路由信息
        res.extendRoute = await file_1.default.read('./extend.route.json', false);
        _nebulaApi.ready(readyHeader, undefined, port, proxyRootPath);
        if (!await this.joinCreateInstace(handle, parsedUrl, req, res))
            return;
        if (!await this.joinOpenInstance(handle, parsedUrl, req, res))
            return;
        if (!await this.joinOpenList(handle, parsedUrl, req, res))
            return;
        if (!await this.joinAppRoute(app, pathname, query, req, res, res.extendRoute))
            return;
        //默认不做处理
        handle(req, res, parsedUrl);
    }
    /**
     * 用户鉴权及系统配置读取
     * @param req
     * @param res
     */
    async authenticate(req, res) {
        //验证鉴权 
        //不需要处理验证cookie
        // let apiCookies = req.headers['cookie'];
        // if(!apiCookies){
        //     //没有cookie携带跳转登录页
        //     res.redirect('/login');
        //     return;
        // }
        let [userInfo, layoutInfo] = await Promise.all([_nebulaApi.getAuthenticate(), file_1.default.read('./static/theme/system.json', false)]);
        if (!userInfo) {
            //鉴权失败跳转登录页
            let loginFail = _nebulaApi.getError();
            // console.log(loginFail.apiResult);
            if (loginFail && !loginFail.apiResult) {
                res.statusCode = 500;
                res.write();
                return;
            }
            if (loginFail && loginFail.apiResult && loginFail.apiResult.data) {
                res.redirect(loginFail.apiResult.data);
                return;
            }
            res.redirect(`/login?redirect=${req.url}`);
            return;
        }
        res.userinfo = userInfo;
        //设置 图片路径的根目录
        let replaceLayoutInfo = layoutInfo;
        if (this.systemAppConfig && replaceLayoutInfo) {
            let rootPath = this.systemAppConfig.proxyRootPath || '';
            rootPath += '/venus/images';
            if (replaceLayoutInfo.logo)
                replaceLayoutInfo.logo = rootPath + replaceLayoutInfo.logo;
            if (replaceLayoutInfo.small_logo)
                replaceLayoutInfo.small_logo = rootPath + replaceLayoutInfo.small_logo;
            if (replaceLayoutInfo.system_icon)
                replaceLayoutInfo.system_icon = rootPath + replaceLayoutInfo.system_icon;
            if (replaceLayoutInfo.background)
                replaceLayoutInfo.background = rootPath + replaceLayoutInfo.background;
        }
        res.layoutinfo = replaceLayoutInfo || {};
        //生成配置的默认主题 如果用户配置主题不存在
        if (!replaceLayoutInfo || !replaceLayoutInfo.lastTime) {
            //读取新的主题信息
            let themeData = await _nebulaApi.get(apiConfig_1.default.FindTheme, {});
            if (themeData) {
                //保存主题布局文件 将配置信息写入系统配置文件中，依赖此文件进行全局输入读取
                const { color, customTheme, theme, ...sysConfig } = themeData;
                sysConfig.lastTime = new Date().getTime();
                sysConfig.extendCss = true;
                sysConfig.themeColor = color && color.variables && color.variables['@primary-color'] || '#0091FF';
                let promises = [];
                promises.push(file_1.default.write('./static/theme/system.json', JSON.stringify(sysConfig, null, '\t')));
                //生成样式文件
                const themeVar = color && color.variables;
                if (themeVar) {
                    let themeVarString1 = Object.entries(themeVar).map(([k, v]) => `${k}:${v}`).join(';');
                    let themeVarString = `@import './static/theme/less/default.less';${themeVarString1};@import './static/theme/less/index.less';`;
                    promises.push(complieLess(themeVarString, './static/css/nebula.theme.css'));
                    //扩展样式生产
                    if (fs_1.default.existsSync(path_1.default.join(process.cwd(), './static/theme/extend/index.less'))) {
                        let extendVarString = `@import './static/theme/less/default.less';${themeVarString1};@import './static/theme/extend/index.less';`;
                        promises.push(complieLess(extendVarString, './static/css/nebula.extend.theme.css'));
                    }
                }
                let [configResult, lessResult, extendLess] = await Promise.all(promises);
                if (!configResult || !lessResult) {
                    console.log('首次主题生成失败');
                }
            }
        }
        return true;
    }
    /**
     * 注入app路由
     * @param app
     * @param req
     * @param res
     */
    async joinAppRoute(app, pathname, query, req, res, extendRoute = []) {
        //TODO app当前只处理了 固定的模块，自定义模块需要读取配置文件
        const routesJson = route_1.default.concat(extendRoute);
        const currPath = routesJson.find((v) => v.path === pathname);
        if (!currPath)
            return true;
        //进入指定路由页面
        let result = await this.authenticate(req, res);
        if (!result)
            return;
        //获取按钮权限和菜单权限
        let auths = await _nebulaApi.getUserButtonAuthAndMenu();
        res.userAuths = auths.userAuths;
        res.userMenus = auths.userMenus;
        result && app.render(req, res, '/', query);
    }
    /**
     * 注入创建实例页面
     * @param app
     * @param pathname
     * @param query
     * @param req
     * @param res
     */
    async joinCreateInstace(handle, parsedUrl, req, res) {
        let route = ['/build', '/build.html'];
        if (!route.some(v => v === parsedUrl.pathname))
            return true;
        //创建表单实例
        //鉴权
        let result = await this.authenticate(req, res);
        if (!result)
            return;
        //获取创建的新实例活动信息
        let activityData = await _nebulaApi.getActivityByTemplate(parsedUrl.query.code);
        if (!activityData) {
            res.errorInfo = _nebulaApi.getError();
            handle(req, res, parsedUrl);
            return;
        }
        let curActivityData = activityData && activityData.activities[0];
        let instanceData = await _nebulaApi.getTemplateInstance(curActivityData.id, 1);
        res.instance = instanceData;
        parsedUrl.pathname = '/build';
        handle(req, res, parsedUrl);
    }
    /**
     * 注入打开实例页面
     * @param app
     * @param pathname
     * @param query
     * @param req
     * @param res
     */
    async joinOpenInstance(handle, parsedUrl, req, res) {
        let route = ['/main', '/main.html'];
        if (!route.some(v => v === parsedUrl.pathname))
            return true;
        //鉴权
        let result = await this.authenticate(req, res);
        if (!result)
            return;
        let queryParam = {};
        //兼容参数大小写
        Object.entries(parsedUrl.query || {}).forEach(([k, v]) => {
            queryParam[k.toLowerCase()] = v;
        });
        //获取指定的实例活动信息
        let activityData = await _nebulaApi.getActivityByTaskCode(queryParam['taskcode'], queryParam['instanceid'], queryParam['visibilityname']);
        if (!activityData) {
            res.errorInfo = _nebulaApi.getError();
            handle(req, res, parsedUrl);
            return;
        }
        //获取活动实例数据
        let instanceData = await _nebulaApi.getTemplateInstance(activityData.id, 1);
        res.instance = instanceData;
        parsedUrl.pathname = '/main';
        handle(req, res, parsedUrl);
    }
    /**
     * 注入打开列表页面
     * @param app
     * @param pathname
     * @param query
     * @param req
     * @param res
     */
    async joinOpenList(handle, parsedUrl, req, res) {
        let route = ['/list', '/engineOutList', '/listInstance'];
        if (!route.some(v => v === parsedUrl.pathname))
            return true;
        let params = parsedUrl.query;
        let validParam = {
            code: params && (params.code || params.nebula_listTempCode),
            id: params && (params.id || params.nebula_listTempId)
        };
        if (!validParam.code && !validParam.id) {
            //参数无效 
            let errorInfo = {
                success: false,
                errorMsg: '参数无效，请指定code或者id'
            };
            res.errorInfo = errorInfo;
            handle(req, res, parsedUrl);
            return;
        }
        //鉴权
        let result = await this.authenticate(req, res);
        if (!result)
            return;
        //获取指定的列表信息
        let listData;
        if (validParam.code)
            listData = await _nebulaApi.getListContentByCode(validParam.code);
        else
            listData = await _nebulaApi.getListContentById(validParam.id);
        if (!listData) {
            res.errorInfo = _nebulaApi.getError();
            handle(req, res, parsedUrl);
            return;
        }
        res.listConfig = listData;
        parsedUrl.pathname = '/list';
        handle(req, res, parsedUrl);
    }
}
exports.default = new PageMiddleware();
