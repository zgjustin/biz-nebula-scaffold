"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = __importDefault(require("http"));
const iconv_lite_1 = __importDefault(require("iconv-lite"));
/**
 * Http请求工具
 */
class HttpRequest {
    constructor() {
        //默认配置
        this._defaultConfig = {
            host: 'localhost',
            port: '5700',
            method: 'GET',
            rootPath: '/v1',
            path: '',
            headers: {
                "Content-Type": 'application/x-www-form-urlencoded; charset=utf-8',
                "Accept": "application/json"
            }
        };
        this._config = null;
        this._header = null;
    }
    /**
     * 设置全局默认配置信息
     * @param option
     */
    configDefault(option) {
        let { headers, ...otherOption } = option;
        this._defaultConfig = { ...this._defaultConfig, ...otherOption };
        this._defaultConfig.headers = { ...this._defaultConfig.headers, ...headers };
    }
    /**
     * 设置http请求配置
     * @param config
     */
    config(option) {
        this._config = option;
        return this;
    }
    /**
     * 设置http请求头
     * @param header
     */
    header(option) {
        this._header = option;
        return this;
    }
    /**
     * 请求数据转换
     * 对象转json格式
     */
    formatData(data) {
        //通过contentType判定 转换数据
        let defaultHeader = this._defaultConfig.headers;
        if (this._header) {
            defaultHeader = { ...defaultHeader, ...this._header };
        }
        let postData;
        if (typeof data === 'object') {
            let contentType = defaultHeader["Content-Type"];
            switch (contentType) {
                case 'application/json; charset=utf-8':
                    postData = JSON.stringify(data);
                    //node默认为unicode编码 需要转换为utf8传http数据
                    postData = iconv_lite_1.default.encode(postData, 'utf8');
                    break;
                case 'multipart/form-data':
                    postData = new FormData();
                    Object.entries(data).forEach(([k, v]) => {
                        postData.append(k, v);
                    });
                    break;
                case 'application/x-www-form-urlencoded; charset=utf-8':
                default:
                    postData = Object.entries(data).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
                    break;
            }
        }
        else {
            postData = data;
        }
        return postData;
    }
    /**
     * 清除指定的配置信息
     */
    clearConfig() {
        //对配置和header进行清除处理
        this._config = undefined;
        this._header = undefined;
    }
    /**
     * http API接口请求
     * @param url 请求url
     * @param method 请求method
     * @param data 请求数据
     * 返回Promise json对象
     */
    send(url, method, data) {
        //请求数据处理
        let postData = this.formatData(data);
        //请求配置处理
        let { rootPath = '', ...requestConfig } = this._defaultConfig;
        if (this._config) {
            requestConfig = { ...requestConfig, ...this._config };
        }
        if (this._header) {
            requestConfig.headers = { ...requestConfig.headers, ...this._header };
        }
        if (method) {
            requestConfig.method = method;
        }
        requestConfig.path = rootPath + url;
        if (typeof postData === 'string' && requestConfig.headers['Content-Type'] === 'application/x-www-form-urlencoded; charset=utf-8') {
            if (requestConfig.path.indexOf('?') != -1) {
                requestConfig.path += `&`;
            }
            else {
                requestConfig.path += '?';
            }
            requestConfig.path += postData;
            postData = '';
        }
        requestConfig.headers["Content-Length"] = postData.length;
        let errorResult = {
            success: false,
            errorMsg: '请求数据错误!'
        };
        this.clearConfig();
        // console.log('ajax:'+url,requestConfig);
        return new Promise(resolve => {
            //接收返回结果
            let body = '';
            //开始发起请求
            let req = http_1.default.request(requestConfig, (res) => {
                res.on('data', (result) => {
                    body += result;
                }).on('end', () => {
                    let result;
                    try {
                        errorResult.errorMsg = '返回体为空' + url;
                        result = body ? JSON.parse(body) : errorResult;
                    }
                    catch (e) {
                        errorResult.errorMsg = '返回体不是json结构' + url;
                        result = errorResult;
                    }
                    if (!result.status || (result.status >= 200 && result.status < 300)) {
                        resolve(result);
                        return;
                    }
                    //http status 异常
                    result.responseCode = result.status;
                    result.errorMsg = result.message;
                    resolve(result);
                });
            }).on('error', (e) => {
                console.log("http-error: " + e.message);
                errorResult.errorMsg = '请求异常' + url;
                resolve(errorResult);
            });
            //推送请求数据
            req.write(postData + '\n');
            //结束请求
            req.end();
        });
    }
}
exports.default = HttpRequest;
