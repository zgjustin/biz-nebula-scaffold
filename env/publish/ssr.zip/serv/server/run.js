"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: justin
 * @Date: 2020-07-25 16:39:37
 * @LastEditTime: 2020-12-07 11:12:23
 * @LastEditors: justin
 * @FilePath: /biz.nebula/nebula.ssr/server/run.ts
 * @Description:
 */
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const http_proxy_middleware_1 = require("http-proxy-middleware");
const next_1 = __importDefault(require("next"));
const pageMiddleware_1 = __importDefault(require("./pageMiddleware"));
const apiMiddleware_1 = __importDefault(require("./apiMiddleware"));
const file_1 = __importDefault(require("./file"));
const app_json_1 = __importDefault(require("../app.json"));
const path_1 = __importDefault(require("path"));
/**
 * 配置文件中拿取配置信息
 */
async function getAppConfig() {
    let appConfig = await file_1.default.read('./app.json', false);
    if (!appConfig)
        return app_json_1.default;
    return { ...app_json_1.default, ...appConfig };
}
/**
 * 获取环境代理
 * @param appConfig
 */
function getEnvPoxyConfig(appConfig) {
    //获取配置中的参数 
    let proxyList = appConfig.proxyEnv;
    if (proxyList && typeof proxyList === 'object' && !Array.isArray(proxyList)) {
        let argvs = process.argv;
        let envVarIndex = argvs.indexOf('-env');
        let env;
        if (envVarIndex > 0) {
            //环境变量 后一个参数为参数值
            env = argvs[envVarIndex + 1];
        }
        //从配置中 找出匹配的环境代理
        let port, proxy;
        let envConfig = proxyList[env];
        if (envConfig) {
            port = envConfig.prot;
            proxy = envConfig.proxy;
            return { port, proxy };
        }
    }
}
/**
 * 运行服务端
 * @param env 运行环境
 * @param argvPort 命令行参数指定端口
 */
function run(production, argvPort, argvProxy) {
    let dev = production ? false : process.env.NODE_ENV !== 'production';
    const app = next_1.default({ dev });
    app.prepare().then(() => {
        const server = express_1.default();
        getAppConfig().then((config) => {
            let envProxy = getEnvPoxyConfig(config);
            if (!envProxy) {
                argvPort = Number(argvPort);
                if (argvPort && !isNaN(argvPort)) {
                    config.port = argvPort;
                }
                if (argvProxy) {
                    config.proxy = argvProxy;
                }
            }
            else {
                config.port = envProxy.port;
                config.proxy = envProxy.proxy;
                if (!config.port || !config.proxy) {
                    console.error('代理无效，请检查代理 app.json -> proxyEnv:{"xxx":{"proxy":"http:xxxx","port":000}');
                    process.exit();
                }
            }
            const port = config.port;
            let rootPath = config.proxyRootPath;
            if (!Array.isArray(rootPath)) {
                rootPath = [rootPath];
            }
            else {
                config.proxyRootPath = rootPath[0] || "/v1";
            }
            rootPath.forEach((rp) => {
                const pathRewrite = {};
                pathRewrite[`^${rp}`] = rp;
                server.use(http_proxy_middleware_1.createProxyMiddleware(rp, {
                    target: config.proxy,
                    secure: false,
                    pathRewrite: pathRewrite,
                    changeOrigin: true
                }));
            });
            //静态资源文件处理 css,js,font等，static文件夹下
            server.use('/static', express_1.default.static(path_1.default.join(process.cwd(), './static')));
            //body内容大小限制2M
            server.use(body_parser_1.default.json({ limit: '100mb' }));
            server.use(body_parser_1.default.urlencoded({ extended: false }));
            //保存并生成主题样式文件
            server.post('/nebula/saveTheme', (req, res) => apiMiddleware_1.default.saveTheme(req, res, config));
            //页面路由处理
            server.get('*', (req, res) => pageMiddleware_1.default.init(app, req, res, config));
            server.listen(port, (err) => {
                if (err)
                    throw err;
                console.log(`> Ready on http://localhost:${port}`);
            });
        });
    });
}
exports.default = run;
