"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: justin
 * @Date: 2020-07-25 16:39:37
 * @LastEditTime: 2020-12-01 16:16:04
 * @LastEditors: justin
 * @FilePath: /biz.nebula/nebula.ssr/server/run.ts
 * @Description:
 */
const express_1 = __importDefault(require("express"));
const body_parser_1 = __importDefault(require("body-parser"));
const http_proxy_middleware_1 = require("http-proxy-middleware");
const next_1 = __importDefault(require("next"));
const pageMiddleware_1 = __importDefault(require("./pageMiddleware"));
const apiMiddleware_1 = __importDefault(require("./apiMiddleware"));
const file_1 = __importDefault(require("./file"));
const app_json_1 = __importDefault(require("../app.json"));
/**
 * 配置文件中拿取配置信息
 */
async function getAppConfig() {
    let appConfig = await file_1.default.read('./app.json', false);
    if (!appConfig)
        return app_json_1.default;
    return { ...app_json_1.default, ...appConfig };
}
/**
 * 运行服务端
 * @param env 运行环境
 * @param argvPort 命令行参数指定端口
 */
function run(production, argvPort, argvProxy) {
    let dev = production ? false : process.env.NODE_ENV !== 'production';
    const app = next_1.default({ dev });
    app.prepare().then(() => {
        const server = express_1.default();
        getAppConfig().then((config) => {
            argvPort = Number(argvPort);
            if (argvPort && !isNaN(argvPort)) {
                config.port = argvPort;
            }
            if (argvProxy) {
                config.proxy = argvProxy;
            }
            const port = config.port;
            let rootPath = config.proxyRootPath;
            if (!Array.isArray(rootPath)) {
                rootPath = [rootPath];
            }
            else {
                config.proxyRootPath = rootPath[0] || "/v1";
            }
            rootPath.forEach((rp) => {
                const pathRewrite = {};
                pathRewrite[`^${rp}`] = rp;
                server.use(http_proxy_middleware_1.createProxyMiddleware(rp, {
                    target: config.proxy,
                    secure: false,
                    pathRewrite: pathRewrite,
                    changeOrigin: true
                }));
            });
            //body内容大小限制2M
            server.use(body_parser_1.default.json({ limit: '100mb' }));
            server.use(body_parser_1.default.urlencoded({ extended: false }));
            //保存并生成主题样式文件
            server.post('/nebula/saveTheme', (req, res) => apiMiddleware_1.default.saveTheme(req, res, config));
            //页面路由处理
            server.get('*', (req, res) => pageMiddleware_1.default.init(app, req, res, config));
            server.listen(port, (err) => {
                if (err)
                    throw err;
                console.log(`> Ready on http://localhost:${port}`);
            });
        });
    });
}
exports.default = run;
