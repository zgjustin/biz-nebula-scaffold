"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: justin
 * @Date: 2020-07-25 16:45:44
 * @LastEditTime: 2020-12-03 16:31:31
 * @LastEditors: justin
 * @FilePath: /biz.nebula/nebula.ssr/server/pro.ts
 * @Description: 生产启动服务端
 */
const run_1 = __importDefault(require("./run"));
if (process.env.NODE_ENV !== 'production') {
    run_1.default(true, process.env.PORT, process.env.proxy);
}
else {
    run_1.default(true);
}
