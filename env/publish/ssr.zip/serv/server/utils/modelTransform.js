"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertFormData = void 0;
/**
 * 模型转换功能实现
 * 将后端模型及关系转换为前端可用模型数据
 * 可用模型数据规范查看规范文档
 * create by justin 2019-1-11
 */
class modelTransform {
    /**
     * 构造函数
     * @param {主模型} mainModel
     * @param {关联模型} relationModel
     * @param {主数据源} mainSource
     * @param {关联数据源} relationSource
     */
    constructor() {
        //model数据
        this.modelData = null;
        //转换后的完整模型数据
        this.fieldData = null;
        //模型转换错误信息
        this.error = null;
        //错误源
        this.errorTarget = null;
    }
    /**
     * 合并模型的基础属性和关联属性
     * @param {合并字段属性} properties
     * @param {要合并的模型} relations
     */
    _mergeModelProperties(properties, relations) {
        if (!properties && !relations)
            return;
        let mergeModal = {};
        properties &&
            properties.forEach((v) => {
                //回溯关系不呈现
                if (v.backProperty)
                    return;
                mergeModal[v.propertyName] = v;
                mergeModal[v.propertyName].field = v.propertyName;
            });
        relations &&
            relations.forEach((v) => {
                //回溯关系不呈现
                if (v.backProperty)
                    return;
                mergeModal[v.propertyName] = v;
                mergeModal[v.propertyName].field = v.propertyName;
            });
        return mergeModal;
    }
    //合并列表项属性
    _mergeItemProperty(itemRelations) {
        let itemModal = {};
        itemRelations.forEach((v) => {
            let { properties, relations, ...baseProperties } = v;
            itemModal[v.propertyName] = { ...baseProperties };
            itemModal[v.propertyName].field = v.propertyName;
            let itemProperties = this._mergeModelProperties(properties, relations);
            itemModal[v.propertyName].itemProperties = itemProperties;
        });
        return itemModal;
    }
    /**
     * 初始化模型数据
     * 转换为前端可用的模型数据
     * 因为模型数据是不能被提交到后端，所以此处的转换不需要对转换后的对象数据做深拷贝
     * 方便修改了转换后模型中数据源对象，原来的数据源对象也会发生更改，可以直接使用数据源数据
     */
    init(modelData) {
        this.error = null;
        this.modelData = modelData;
        this.fieldData = {};
        try {
            //合并基础属性和关联属性
            Object.assign(this.fieldData, this._mergeModelProperties(this.modelData.properties, this.modelData.relations));
            //合并分组属性
            if (this.modelData.groupRelations &&
                this.modelData.groupRelations.length > 0) {
                this.modelData.groupRelations.forEach((v) => {
                    let { properties, relations, itemRelations, ...baseProperties } = v;
                    this.fieldData[v.propertyName] = { ...baseProperties };
                    this.fieldData[v.propertyName].field = v.propertyName;
                    this.fieldData[v.propertyName].group = v.propertyName;
                    let groupProperties = this._mergeModelProperties(properties, relations);
                    if (itemRelations && itemRelations.length > 0) {
                        Object.assign(groupProperties, this._mergeItemProperty(itemRelations));
                    }
                    Object.entries(groupProperties).forEach(([gi, gv]) => {
                        let groupField = `${gi}-${v.propertyName}`;
                        gv.field = groupField;
                        this.fieldData[groupField] = gv;
                    });
                });
            }
            //合并列表项属性
            if (this.modelData.itemRelations &&
                this.modelData.itemRelations.length > 0) {
                Object.assign(this.fieldData, this._mergeItemProperty(this.modelData.itemRelations));
            }
        }
        catch (err) {
            this.error = err;
            console.error(this.error, this.errorTarget);
            //解析出错 模型数据初始为null
            this.fieldData = null;
        }
    }
    /**
     * 获得转换模型错误信息
     */
    getError() {
        return this.error;
    }
    /**
     * 获得字段数据
     */
    getFieldData() {
        return this.fieldData;
    }
}
exports.default = modelTransform;
/**
 * 将表单提交数据转换为 后端需要的真实结构数据
 * 主要是OneToOne关系的 分组情况，需要转换分组字段为子模型到分组字段中
 * 字段名含有_的 表示需要进行组装
 * @param {表单提交数据} formData
 */
exports.convertFormData = (formData) => {
    let realFormData = {};
    let groupData = {};
    Object.entries(formData).forEach(([k, v]) => {
        let names = k.split('-');
        if (names.length >= 2) {
            if (!groupData[names[0]]) {
                groupData[names[0]] = {};
            }
            groupData[names[0]][names[1]] = v;
        }
        else {
            realFormData[k] = v;
        }
    });
    Object.entries(groupData).forEach(([k, v]) => {
        realFormData[k] = v;
    });
    return realFormData;
};
