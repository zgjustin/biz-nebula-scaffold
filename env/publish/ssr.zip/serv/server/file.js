"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * 服务端文件读写API
 * by justin 2020-7-3
 */
class File {
    /**
     * 转换指定相对路径为当前项目下对应路径
     * @param filePath 相对路径
     */
    static convertFilePath(filePath) {
        return path_1.default.join(process.cwd(), filePath);
    }
    /**
     * 文件或路径是否存在
     * @param path
     */
    static exits(pathName) {
        return fs_1.default.existsSync(path_1.default.join(process.cwd(), pathName));
    }
    /**
     * 将指定内容写入指定路径的文件
     * @param {*} fileName 文件路径，当前项目所在根目录作为启始
     * @param {*} data 写入文件的数据 支持字符串或者json对象
     */
    static write(fileName, data) {
        return new Promise((resolve) => {
            let file = File.convertFilePath(fileName);
            let saveData = typeof data === 'object' ? JSON.stringify(data) : data;
            fs_1.default.writeFile(file, saveData, function (err) {
                if (err) {
                    resolve(false);
                    return console.error('fileError', err);
                }
                resolve(true);
            });
        });
    }
    /**
     * 读取指定路径的文件
     * 如果指定的文件类型为.json 则自动转换返回数据为json对象
     * @param {*} file 文件路径，当前项目所在根目录作为启始
     */
    static read(fileName, showError = true) {
        return new Promise((resolve, reject) => {
            let file = File.convertFilePath(fileName);
            let needJsonParse = false;
            //判定文件类型
            if (path_1.default.extname(fileName) === '.json') {
                needJsonParse = true;
            }
            fs_1.default.readFile(file, function (err, data) {
                if (err) {
                    showError && console.error('fileError', err);
                    resolve(false);
                    return;
                }
                let readData = data.toString();
                if (needJsonParse) {
                    try {
                        return resolve(JSON.parse(readData));
                    }
                    catch (jsonError) {
                        console.error('nebula-file-json-error', readData, jsonError);
                        return resolve(false);
                    }
                }
                return resolve(readData);
            });
        });
    }
}
exports.default = File;
