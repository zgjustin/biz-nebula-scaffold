"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const nebulaApi_1 = __importDefault(require("./nebulaApi"));
const apiConfig_1 = __importDefault(require("./nebulaApi/apiConfig"));
const file_1 = __importDefault(require("./file"));
const less_1 = __importDefault(require("less"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const _nebulaApi = new nebulaApi_1.default();
/**
 * 编译less文件到对应的文件
 * @param {*} input less文本
 * @param {*} fileName 输入文件名
 */
function complieLess(input, fileName) {
    return new Promise(resolve => {
        less_1.default.render(input, { javascriptEnabled: true }, (error, out) => {
            if (error) {
                console.error('less render:', error);
                resolve(false);
                return;
            }
            file_1.default.write(fileName, out.css).then(data => {
                resolve(data);
            });
        });
    });
}
/**
 * 处理ssr提供的Api接口
 */
class ApiMiddleware {
    /**
     * 保存主题
     * /nebula/saveTheme
     */
    async saveTheme(req, res, appConfig) {
        //准备请求
        let { proxyRootPath, port } = appConfig || {};
        _nebulaApi.ready(req.headers, undefined, port, proxyRootPath);
        let postData = req.body;
        let saveResult = await _nebulaApi.post(apiConfig_1.default.SaveTheme, postData);
        if (!saveResult) {
            res.json(_nebulaApi.getError());
            return;
        }
        //保存主题布局文件 将配置信息写入系统配置文件中，依赖此文件进行全局输入读取
        const { color, customTheme, theme, ...sysConfig } = postData;
        //生成样式文件
        const themeVar = color && color.variables;
        if (themeVar) {
            let themeVarString = Object.entries(themeVar).map(([k, v]) => `${k}:${v}`).join(';');
            themeVarString = `@import './static/theme/less/default.less';${themeVarString};@import './static/theme/less/index.less';`;
            let lessResult = await complieLess(themeVarString, './static/css/nebula.theme.css');
            if (lessResult === false) {
                res.json({ success: false, errorMsg: '保存主题失败' });
                return;
            }
            //扩展样式生产
            if (fs_1.default.existsSync(path_1.default.join(process.cwd(), './static/theme/extend/index.less'))) {
                let extendVarString = `@import './static/theme/less/default.less';${themeVarString};@import './static/theme/extend/index.less';`;
                let extendResult = await complieLess(extendVarString, './static/css/nebula.extend.theme.css');
                if (extendResult === false) {
                    res.json({ success: false, errorMsg: '保存主题失败,扩展样式实效' });
                    return;
                }
                sysConfig.extendCss = true;
            }
        }
        //保存配置
        sysConfig.lastTime = new Date().getTime();
        let configResult = await file_1.default.write('./static/theme/system.json', JSON.stringify(sysConfig, null, '\t'));
        if (configResult === false) {
            res.json({ success: false, errorMsg: '保存配置文件失败' });
            return;
        }
        res.json(saveResult);
    }
    /**
     * 保存导入主题
     * @param req
     * @param res
     * @param appConfig
     */
    async saveImport(req, res, appConfig) {
        //准备请求
        let { proxyRootPath, port } = appConfig || {};
        _nebulaApi.ready(req.headers, undefined, port, proxyRootPath);
        let postData = req.body;
        let saveResult = await _nebulaApi.post(apiConfig_1.default.SaveThemeImport, postData);
        if (!saveResult) {
            res.json(_nebulaApi.getError());
            return;
        }
        //读取新的主题信息
        let themeData = await _nebulaApi.get(apiConfig_1.default.FindTheme, {});
        if (!themeData) {
            res.json(_nebulaApi.getError());
            return;
        }
        //保存主题布局文件 将配置信息写入系统配置文件中，依赖此文件进行全局输入读取
        const { color, customTheme, theme, ...sysConfig } = themeData;
        sysConfig.lastTime = new Date().getTime();
        sysConfig.themeColor = color && color.variables && color.variables['@primary-color'] || '#0091FF';
        let promises = [];
        promises.push(file_1.default.write('./static/theme/system.json', JSON.stringify(sysConfig)));
        //生成样式文件
        const themeVar = color && color.variables;
        if (themeVar) {
            let themeVarString = Object.entries(themeVar).map(([k, v]) => `${k}:${v}`).join(';');
            themeVarString = `@import './static/theme/less/default.less';${themeVarString};@import './static/theme/less/index.less';`;
            promises.push(complieLess(themeVarString, './static/css/nebula.theme.css'));
        }
        let [configResult, lessResult] = await Promise.all(promises);
        if (configResult === false) {
            res.json({ success: false, errorMsg: '保存配置文件失败' });
            return;
        }
        if (lessResult === false) {
            res.json({ success: false, errorMsg: '保存主题失败' });
            return;
        }
        res.json(saveResult);
    }
}
exports.default = new ApiMiddleware();
