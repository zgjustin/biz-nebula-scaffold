"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * path: // 用于进行比对的路径
 * app: // 当前的模块名称
 * module：
 */
const routes = [
    {
        path: '/',
        app: '',
        module: '',
        entry: ''
    },
    {
        path: '/codeRule',
        app: "account",
        module: "CodeRule"
    },
    {
        path: '/buttonAuthorityManage',
        app: "account",
        module: "Function"
    },
    {
        path: '/envVariable',
        app: "account",
        module: "GlobalParam"
    },
    {
        path: '/menuAuthorityManage',
        app: "account",
        module: "Menu"
    },
    {
        path: '/themeManage',
        app: "account",
        module: "ThemeManage"
    },
    {
        path: '/organizationManagement',
        app: "account",
        module: "Organization"
    },
    {
        path: '/positionManagement',
        app: "account",
        module: "Position"
    },
    {
        path: '/roleManagement',
        app: "account",
        module: "Roles"
    },
    {
        path: '/scheduler',
        app: "account",
        module: "Scheduler"
    },
    {
        path: '/accountManagement',
        app: "account",
        module: "User"
    },
    {
        path: '/usersGroupManagement',
        app: "account",
        module: "UserGroup"
    },
    {
        path: '/roleRelation',
        app: "account",
        module: "RoleRelation"
    },
    // 配置组织关系
    {
        path: '/orgBindRelation',
        app: "account"
    },
    // 组织绑定用户
    {
        path: '/orgBindUserModal',
        app: "account"
    },
    // 组织绑定角色
    {
        path: '/orgBindRoleModal',
        app: "account"
    },
    // 配置用户组关系
    {
        path: '/userGroupBindRelation',
        app: "account"
    },
    // 用户组绑定用户
    {
        path: '/userGroupBindUser',
        app: "account"
    },
    // 用户组绑定角色
    {
        path: '/userGroupBindRole',
        app: "account"
    },
    // 用户绑定角色
    {
        path: '/userBindRole',
        app: "account"
    },
    // 职位绑定用户
    {
        path: '/positionBindUser',
        app: "account"
    },
    // 职位绑定角色
    {
        path: '/positionBindRole',
        app: "account"
    },
    // 职位绑定关系
    {
        path: '/positionBindRelation',
        app: "account"
    },
    // 权限配置
    {
        path: '/roleAuthSetting',
        app: "account"
    },
    // 查看职位详情
    {
        path: '/positionDetail',
        app: "account"
    },
    // 关联区域层级
    {
        path: '/settingRegeon',
        app: "account"
    },
    // 关联区域
    {
        path: '/settingOrgRegeon',
        app: "account"
    },
    {
        path: '/markdown',
        app: "doc",
        module: "Markdown"
    },
    {
        path: '/dataviewsourcemanage/manage',
        app: "datasource",
        module: "DataviewSourceManage"
    },
    {
        path: '/serviceSource',
        app: "datasource",
        module: "ServiceSource"
    },
    {
        path: '/dataviewsourcemanage',
        app: "datasource",
        module: "DataView"
    },
    {
        path: '/remoteServiceAddressManage',
        app: "datasource",
        module: "RemoteServiceAddressManage"
    },
    {
        path: '/datasourcemanage',
        app: "datasource",
        module: "DatasourceManage"
    },
    {
        path: '/prevalue',
        app: "datasource",
        module: "PreValue"
    },
    {
        path: '/enum',
        app: "datasource",
        module: "Enum"
    },
    {
        path: '/dataAuth/manage',
        app: "datasource",
        module: "DataAuthManage"
    },
    {
        path: '/remoteservicemanage',
        app: "datasource",
        // module:"RemoteCallManage"
        module: 'RemoteServiceManage'
    },
    {
        path: '/dataAuth',
        app: "datasource",
        module: "DataAuth"
    },
    {
        path: '/listTemplate',
        app: "page",
        module: "ListTemplate"
    },
    {
        path: '/listTemplate/setting',
        app: "page",
        module: "ListTemplate"
    },
    {
        path: '/listTemplate/browser',
        app: "page",
        module: "ListTemplate"
    },
    {
        path: '/pageflow',
        app: "page",
        module: "PageFlow"
    },
    {
        path: '/pageInstance',
        app: "page",
        module: "PageInstance"
    },
    {
        path: '/template',
        app: "page",
        module: "Template"
    },
    {
        path: '/template/modal',
        app: "page",
        module: "Template"
    },
    {
        path: '/template/dynamicTemplate',
        app: "page",
        module: "Template"
    },
    {
        path: "/flow/flowcontrol",
        app: "flow"
    },
    {
        path: "/flow/flowcontrol/edit",
        app: "flow"
    },
    {
        path: "/flow/flowcontrol/inspection",
        app: "flow"
    },
    {
        path: "/flow/flowcontrol/detail",
        app: "flow"
    },
    {
        path: "/flow/flowInstance",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/detail",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/list",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/copy",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/waiting",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/done",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/launchBySelf",
        app: "flow"
    },
    {
        path: "/flow/flowInstance/useableFlowTemp",
        app: "flow"
    },
    {
        path: "/flow/operation",
        app: "flow"
    },
    {
        path: "/flow/monitor",
        app: "flow"
    },
    {
        path: '/engineList',
        app: "page",
        module: "engineList"
    },
    {
        path: '/engineOutList',
        app: "page",
        module: "engineList"
    },
    {
        path: '/custom',
        app: "page",
        module: "CustomPage"
    },
    {
        path: '/listCustomPage',
        app: 'page',
        module: "Page"
    },
    {
        path: '/flowmain',
        app: 'page',
        module: "Page",
        framework: false
    },
    {
        path: '/listChangeLog',
        app: 'page',
        module: "Page",
        framework: false
    },
    {
        path: '/dataTableManage',
        app: "datasource",
        module: "Template"
    },
    {
        path: '/func',
        app: "page",
        module: "GlobalFunc"
    },
    {
        path: '/instance',
        app: "page",
        module: "Instance"
    },
    {
        path: "/instance/changeLog",
        app: "page",
        module: "instance"
    },
    {
        path: '/instance/activity/form',
        app: "page",
        module: "InstancePage"
    },
    {
        path: '/listOpenInstance',
        app: "page",
        module: "ListOpenInstance"
    },
    {
        path: '/preview',
        app: "page",
        module: "Preview"
    },
    {
        path: '/instance/activity',
        app: "page",
        module: "LookStory"
    },
    {
        path: '/migration/basic/import',
        app: "datasource",
        module: "ExportInOut"
    },
    {
        path: "/logPage",
        app: "page",
        module: 'LogPage'
    },
    {
        path: "/logRule",
        app: "page",
        module: 'LogRule'
    },
    {
        path: "/logFieldMapping",
        app: "page",
        module: 'LogFieldMapping'
    },
    {
        path: '/trans',
        app: "district",
        module: "district"
    },
    {
        path: '/authority_manage',
        app: "district",
        module: "district"
    },
    {
        path: '/customer_terminal',
        app: "district",
        module: "district"
    },
    {
        path: '/user_manage',
        app: "district",
        module: "district"
    },
    {
        path: '/admin_division',
        app: "district",
        module: "district"
    },
    {
        path: '/default_role',
        app: "district",
        module: "district"
    },
    {
        path: '/connect_job',
        app: "district",
        module: "district"
    },
    {
        path: '/role_manage',
        app: "district",
        module: "district"
    },
    {
        path: '/org_manage',
        app: "district",
        module: "district"
    },
    {
        path: "/ruleTemplate",
        module: "rules",
        app: 'rules',
        framework: false
    },
    {
        path: "/rulelist",
        module: "rules",
        app: 'rules'
    },
    {
        path: "/demo-user-filter",
        module: "rules",
        app: 'rules',
        framework: false
    },
    {
        path: "/rule/definitions",
        module: "rules",
        app: 'rules'
    }
];
exports.default = routes;
